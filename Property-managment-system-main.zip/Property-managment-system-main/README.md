# Property-managment-system
## FS Mini project
### Python Tkinter
### File compression
### Hashing
### Primary indexing
### Key sort
### Binary search

<img src="bg3.png" alt="PMS"/>
